/*
 * DIO.h
 *
 *  Created on: Oct 10, 2016
 *      Author: ahmed
 */

#ifndef DIO_H_
#define DIO_H_

#define SET_BIT(Register,Pin)       (Register |=(1<<Pin))
#define CLEAR_BIT(Register,Pin)     (Register &=~(1<<Pin))
#define BIT_SET(Register,Pin)       (Register &(1<<Pin))
#define BIT_CLEARED(Register,Pin)   (!(Register &(1<<Pin)))
#define PORT_A 0
#define PORT_B 1
#define PORT_C 2
#define PORT_D 3
/********************************/
#define LOW 0
#define HIGH 1
/******* Directions **************/
#define IPWR 0
#define IPWOR 1
#define OUTPUT 2

/*********** Port values *********/
#define SET_PORT 0xFF
#define CLEAR_PORT 0x00

#endif /* DIO_H_ */

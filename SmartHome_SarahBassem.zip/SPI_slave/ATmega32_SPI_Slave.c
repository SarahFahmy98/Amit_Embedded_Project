/*
 * ATmega32_SPI_Slave.c
 * http://www.electronicwings.com
 */ 


#define F_CPU 16000000UL					/* Define CPU Frequency e.g. here its 8MHz */
#include <avr/io.h>						/* Include AVR std. library file */
#include <util/delay.h>					/* Include Delay header file */
#include <stdio.h>
#include <string.h>						/* Include string header file */
#include "LCD_16x2_H_file.h"			/* Include LCD header file */
#include "SPI_Slave_H_file.h"			/* Include SPI slave header file */
#include "DIO.h"

int main(void)
{
	uint8_t count;
	char buffer[5];
	LCD_Init();
	SPI_Init();
	DDRA=0xFF;
    PORTA=0x00;
	while (1)
	{
		count = SPI_Receive();
		//sprintf(buffer, "%d   ", count);
		//LCD_String_xy(2, 0, buffer);
		switch(count){
		case 1:

			LCD_String_xy(1, 0, "TV is on");
			SET_BIT(PORTA,0);


			break;
	    case 4:

			LCD_String_xy(1, 0, "TV is off");
			CLEAR_BIT(PORTA,0);
			break;
         case 6:

			LCD_String_xy(1, 0, "Washer is on");
			SET_BIT(PORTA,3);
			break;
         case 2:
        	 LCD_String_xy(1, 0, "Washer is off");
        	 CLEAR_BIT(PORTA,3);
        	 break;
         //default:

        	// LCD_String_xy(1, 0, "Invalid entry");

        	//break;
	}



}
}

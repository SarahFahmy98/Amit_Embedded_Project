/*
 * main.c
 *
 *  Created on: Jun 28, 2019
 *      Author: Sami
 */


#define F_CPU 16000000UL
#include <avr/io.h>

#include "LCD.h"
#include "UART.h"
#include "PLATFORM_TYPES.h"
#include "DIO.h"
#include "util/delay.h"
#include "SPI_Master_H_file.h"
#include <string.h>
#include <stdio.h>
void main()
{
	DDRC=0xFF;
	PORTC=0x00;
	LCD_Init();
	SPI_Init();
	char arr[10];
	uint8_t count;
	while(1)
	{

		 bluetooth_receive(arr);

		LCD_Send_String_Row_Column(1,1,arr);


		if(compareString(arr,"TV_on"))
		{
			count=1;
			SPI_Write(count);
		}
		else if(compareString(arr,"TV_off"))
		{
			count=4;
			SPI_Write(count);

		}else if(compareString(arr,"Washer_on"))
		{
			count=6;
			SPI_Write(count);


		}
		else if(compareString(arr,"Washer_off"))
				{
				count=2;
				SPI_Write(count);


				}else{
			count=7;
		SPI_Write(count);
	}
	}
}






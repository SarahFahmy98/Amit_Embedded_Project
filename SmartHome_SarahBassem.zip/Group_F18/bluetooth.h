


#ifndef BLUETOOTH_H_
#define BLUETOOTH_H_

extern void bluetooth_transmit (char *ptr);
extern void bluetooth_receive (char *ptr);


#endif /* BLUETOOTH_H_ */

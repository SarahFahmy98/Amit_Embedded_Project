/*
 * bluetooth.c
 *
 * Created: 3/22/2019 8:24:50 PM
 *  Author: Mohamed Ahmed
 */ 

#include "PLATFORM_TYPES.h"
#include "DIO.h"

#include "UART.h"


void bluetooth_transmit (  char *ptr)
{
	Uart_init(9600);
	UART_send_string(ptr);
}

void bluetooth_receive (char *ptr)
{

	Uart_init(9600);
	UART_recieve_string(ptr);
}


/*
 * DIO.h
 *
 *  Created on: Oct 10, 2016
 *      Author: ahmed
 */

#ifndef DIO_H_
#define DIO_H_

#define SET_BIT(Register,Pin)       (Register |=(1<<Pin))
#define CLEAR_BIT(Register,Pin)     (Register &=~(1<<Pin))
#define BIT_SET(Register,Pin)       (Register &(1<<Pin))
#define BIT_CLEARED(Register,Pin)   (!(Register &(1<<Pin)))
#define PORT_A 0
#define PORT_B 1
#define PORT_C 2
#define PORT_D 3
/********************************/
#define LOW 0
#define HIGH 1
/******* Directions **************/
#define IPWR 0
#define IPWOR 1
#define OUTPUT 2

/*********** Port values *********/
#define SET_PORT 0xFF
#define CLEAR_PORT 0x00
extern void DIO_vSetPinDirection(uint8 Copy_u8PORT,uint8 Copy_u8PinNumber,uint8 copy_u8state);
extern void DIO_vWritePin(uint8 Copy_u8PORT,uint8 Copy_u8PinNumber,uint8 Copy_u8value);
extern void DIO_vTogglePin(uint8 Copy_u8PORT,uint8 Copy_u8PinNumber);
extern void DIO_vSetPortDirection(uint8 Copy_u8PORT,uint8 copy_u8state);
extern void DIO_vWritePort(uint8 Copy_u8PORT,uint8 Copy_u8value);
extern uint8 DIO_u8GetPinValue(uint8 Copy_u8PORT,uint8 Copy_u8PinNumber);
extern void DIO_vTogglrPort(uint8 Copy_u8PORT);
extern void DIO_vWritePortValue(uint8 Copy_u8PORT,uint8 Copy_u8value);
#endif /* DIO_H_ */
